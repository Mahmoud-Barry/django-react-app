import React from "react";

function Hello() {
  return (
    <div>
      <h1>Hello Django React App :) !</h1>
    </div>
  );
}


export default Hello;
